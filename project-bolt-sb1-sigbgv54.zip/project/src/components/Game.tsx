import React, { useEffect, useRef, useState } from 'react';
import { useGameEngine } from '../game/engine';
import GameUI from './GameUI';

const Game: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);
  const [ammo, setAmmo] = useState(30);
  const [rocketFuel, setRocketFuel] = useState(100);
  const [wave, setWave] = useState(1);

  const { startGame, stopGame, restartGame } = useGameEngine({
    canvasRef,
    onScoreChange: setScore,
    onHealthChange: setHealth,
    onAmmoChange: setAmmo,
    onFuelChange: setRocketFuel,
    onWaveChange: setWave,
    onGameOver: () => setGameOver(true)
  });

  useEffect(() => {
    if (health <= 0) {
      setGameOver(true);
      stopGame();
    }
  }, [health, stopGame]);

  const handleStartGame = () => {
    setGameStarted(true);
    setGameOver(false);
    startGame();
  };

  const handleRestartGame = () => {
    setGameOver(false);
    setHealth(100);
    setAmmo(30);
    setRocketFuel(100);
    setScore(0);
    setWave(1);
    restartGame();
  };

  return (
    <div className="relative w-full max-w-4xl aspect-video">
      {!gameStarted && !gameOver && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 bg-black bg-opacity-70 text-white">
          <h1 className="text-4xl font-bold mb-8 text-center">Rocket Militia</h1>
          <p className="mb-6 text-center">
            Use WASD to move, SPACE for rocket boots, and MOUSE to aim and shoot
          </p>
          <button
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
            onClick={handleStartGame}
          >
            Start Game
          </button>
        </div>
      )}

      {gameOver && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 bg-black bg-opacity-70 text-white">
          <h2 className="text-3xl font-bold mb-4">Game Over</h2>
          <p className="text-xl mb-2">Final Wave: {wave}</p>
          <p className="text-xl mb-6">Your score: {score}</p>
          <button
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
            onClick={handleRestartGame}
          >
            Play Again
          </button>
        </div>
      )}

      <canvas
        ref={canvasRef}
        className="w-full h-full bg-gray-800 rounded-lg shadow-lg"
      />

      {gameStarted && !gameOver && (
        <GameUI score={score} health={health} ammo={ammo} fuel={rocketFuel} wave={wave} />
      )}
    </div>
  );
};

export default Game;