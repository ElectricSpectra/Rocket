import React from 'react';
import { Heart, Gauge, Trophy, Bomb, Swords } from 'lucide-react';

interface GameUIProps {
  score: number;
  health: number;
  ammo: number;
  fuel: number;
  wave: number;
}

const GameUI: React.FC<GameUIProps> = ({ score, health, ammo, fuel, wave }) => {
  const pointsNeeded = wave * 100;

  return (
    <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-start pointer-events-none">
      {/* Left UI section - Health and Fuel */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 bg-black bg-opacity-50 p-2 rounded-lg">
          <Heart className={`w-5 h-5 ${health <= 30 ? 'text-red-500 animate-pulse' : 'text-red-400'}`} />
          <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-red-500 transition-all duration-300" 
              style={{ width: `${health}%` }} 
            />
          </div>
          <span className="text-white text-xs">{health}</span>
        </div>
        
        <div className="flex items-center gap-2 bg-black bg-opacity-50 p-2 rounded-lg">
          <Gauge className={`w-5 h-5 ${fuel <= 20 ? 'text-yellow-500 animate-pulse' : 'text-yellow-400'}`} />
          <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-yellow-500 transition-all duration-300" 
              style={{ width: `${fuel}%` }} 
            />
          </div>
          <span className="text-white text-xs">{fuel}</span>
        </div>
      </div>
      
      {/* Center UI section - Wave and Progress */}
      <div className="absolute left-1/2 -translate-x-1/2 top-0 flex flex-col items-center gap-2">
        <div className="flex items-center gap-2 bg-black bg-opacity-50 px-4 py-2 rounded-lg">
          <Swords className="w-5 h-5 text-purple-400" />
          <span className="text-white text-sm font-bold">Wave {wave}</span>
        </div>
        <div className="flex items-center gap-2 bg-black bg-opacity-50 px-4 py-2 rounded-lg">
          <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-purple-500 transition-all duration-300" 
              style={{ width: `${(score / pointsNeeded) * 100}%` }} 
            />
          </div>
          <span className="text-white text-xs">{score}/{pointsNeeded}</span>
        </div>
      </div>
      
      {/* Right UI section - Score and Ammo */}
      <div className="flex flex-col gap-2 items-end">
        <div className="flex items-center gap-2 bg-black bg-opacity-50 p-2 rounded-lg">
          <Trophy className="w-5 h-5 text-yellow-400" />
          <span className="text-white text-sm">{score}</span>
        </div>
        
        <div className="flex items-center gap-2 bg-black bg-opacity-50 p-2 rounded-lg">
          <span className="text-white text-sm">{ammo}</span>
          <Bomb className={`w-5 h-5 ${ammo <= 5 ? 'text-blue-500 animate-pulse' : 'text-blue-400'}`} />
        </div>
      </div>
    </div>
  );
};

export default GameUI;