export interface InputState {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  shoot: boolean;
  boost: boolean;
}

export function handleInput(event: KeyboardEvent, isKeyDown: boolean, state: InputState) {
  switch (event.code) {
    case 'KeyA':
    case 'ArrowLeft':
      state.left = isKeyDown;
      break;
    case 'KeyD':
    case 'ArrowRight':
      state.right = isKeyDown;
      break;
    case 'KeyW':
    case 'ArrowUp':
      state.up = isKeyDown;
      break;
    case 'KeyS':
    case 'ArrowDown':
      state.down = isKeyDown;
      break;
    case 'Space':
      state.boost = isKeyDown;
      break;
  }
}