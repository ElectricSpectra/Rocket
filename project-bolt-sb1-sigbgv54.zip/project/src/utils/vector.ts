export interface Vector2D {
  x: number;
  y: number;
}

export function normalize(vector: Vector2D): Vector2D {
  const magnitude = Math.sqrt(vector.x * vector.x + vector.y * vector.y);
  
  if (magnitude === 0) {
    return { x: 0, y: 0 };
  }
  
  return {
    x: vector.x / magnitude,
    y: vector.y / magnitude
  };
}

export function distance(v1: Vector2D, v2: Vector2D): number {
  const dx = v2.x - v1.x;
  const dy = v2.y - v1.y;
  return Math.sqrt(dx * dx + dy * dy);
}