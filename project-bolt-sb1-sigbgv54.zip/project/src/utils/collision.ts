import { GameObject } from '../game/player';
import { Projectile } from '../game/weapons';

export function checkCollision(obj1: Projectile, obj2: GameObject): boolean {
  const dx = obj1.position.x - obj2.position.x;
  const dy = obj1.position.y - obj2.position.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  return distance < (obj1.radius + obj2.radius);
}