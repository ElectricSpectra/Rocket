import React, { useEffect } from 'react';
import Game from './components/Game';

function App() {
  useEffect(() => {
    // Update the document title
    document.title = "Rocket Militia";
    
    // Prevent default space bar scrolling
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center overflow-hidden">
      <Game />
    </div>
  );
}

export default App;