import { Vector2D } from '../utils/vector';
import { createNPC } from './npc';
import { createBoss } from './bosses';

export interface Wave {
  number: number;
  enemyCount: number;
  enemiesSpawned: number;
  enemiesDefeated: number;
  spawnDelay: number;
  spawnTimer: number;
  hasBoss: boolean;
  bossSpawned: boolean;
  complete: boolean;
  pointsForNextWave: number;
}

export function createWaveManager() {
  let currentWave: Wave = {
    number: 1,
    enemyCount: 5,
    enemiesSpawned: 0,
    enemiesDefeated: 0,
    spawnDelay: 3,
    spawnTimer: 3,
    hasBoss: false,
    bossSpawned: false,
    complete: false,
    pointsForNextWave: 100
  };

  function calculateWaveStats(waveNumber: number): Wave {
    const baseEnemies = 5;
    const enemyIncrease = Math.floor(waveNumber * 1.5);
    const hasBoss = waveNumber % 2 === 0; // Boss every 2nd wave

    return {
      number: waveNumber,
      enemyCount: baseEnemies + enemyIncrease,
      enemiesSpawned: 0,
      enemiesDefeated: 0,
      spawnDelay: Math.max(1, 3 - waveNumber * 0.2), // Spawn faster in later waves
      spawnTimer: 3,
      hasBoss,
      bossSpawned: false,
      complete: false,
      pointsForNextWave: waveNumber * 100 // Each wave requires 100 more points
    };
  }

  function startNextWave() {
    currentWave = calculateWaveStats(currentWave.number + 1);
  }

  function checkScoreForNextWave(score: number): boolean {
    return score >= currentWave.pointsForNextWave;
  }

  function update(deltaTime: number, gameArea: { width: number; height: number }, playerPos: Vector2D, score: number) {
    // Check if we should start next wave based on score
    if (checkScoreForNextWave(score) && !currentWave.hasBoss) {
      startNextWave();
      return null;
    }

    if (currentWave.complete) return null;

    currentWave.spawnTimer -= deltaTime;

    // Regular enemy spawning
    if (currentWave.spawnTimer <= 0 && currentWave.enemiesSpawned < currentWave.enemyCount) {
      currentWave.spawnTimer = currentWave.spawnDelay;
      currentWave.enemiesSpawned++;
      return createNPC(getSpawnPosition(gameArea, playerPos), currentWave.number);
    }

    // Boss spawning
    if (currentWave.hasBoss && 
        !currentWave.bossSpawned && 
        currentWave.enemiesDefeated >= currentWave.enemyCount) {
      currentWave.bossSpawned = true;
      return createBoss(getSpawnPosition(gameArea, playerPos), currentWave.number);
    }

    return null;
  }

  function getSpawnPosition(gameArea: { width: number; height: number }, playerPos: Vector2D): Vector2D {
    const buffer = 50;
    const side = Math.floor(Math.random() * 4);
    let position: Vector2D;

    switch (side) {
      case 0: // Top
        position = { x: Math.random() * gameArea.width, y: -buffer };
        break;
      case 1: // Right
        position = { x: gameArea.width + buffer, y: Math.random() * gameArea.height };
        break;
      case 2: // Bottom
        position = { x: Math.random() * gameArea.width, y: gameArea.height + buffer };
        break;
      case 3: // Left
        position = { x: -buffer, y: Math.random() * gameArea.height };
        break;
      default:
        position = { x: Math.random() * gameArea.width, y: -buffer };
    }

    const minDistance = 200;
    const distToPlayer = Math.sqrt(
      Math.pow(position.x - playerPos.x, 2) + Math.pow(position.y - playerPos.y, 2)
    );

    if (distToPlayer < minDistance) {
      return getSpawnPosition(gameArea, playerPos);
    }

    return position;
  }

  function onEnemyDefeated(isBoss: boolean) {
    if (!isBoss) {
      currentWave.enemiesDefeated++;
    }

    if ((currentWave.enemiesDefeated >= currentWave.enemyCount) && 
        (!currentWave.hasBoss || (currentWave.hasBoss && isBoss))) {
      currentWave.complete = true;
    }
  }

  return {
    get currentWave() { return currentWave; },
    startNextWave,
    update,
    onEnemyDefeated,
    checkScoreForNextWave
  };
}