import { InputState } from '../utils/input';
import { Vector2D } from '../utils/vector';

export interface GameObject {
  position: Vector2D;
  velocity: Vector2D;
  radius: number;
  health: number;
  maxHealth: number;
}

interface PlayerConfig {
  x: number;
  y: number;
}

export function createPlayer({ x, y }: PlayerConfig) {
  // Player state
  const position: Vector2D = { x, y };
  const velocity: Vector2D = { x: 0, y: 0 };
  const acceleration: Vector2D = { x: 0, y: 0 };
  let rotation = 0;
  let health = 100;
  const maxHealth = 100;
  let ammo = 30;
  const maxAmmo = 30;
  let fuel = 100;
  const maxFuel = 100;
  let shootCooldown = 0;
  const shootCooldownTime = 0.2; // 200ms between shots
  let reloadTime = 0;
  const fullReloadTime = 2; // 2 seconds to reload
  
  // Power-up state
  let damageMultiplier = 1;
  let damageBoostTimer = 0;
  let damageBoostDuration = 0;
  
  // Player constants
  const radius = 15;
  const moveSpeed = 200; // Pixels per second
  const boostSpeed = 400; // Rocket boost speed
  const friction = 0.9; // Friction to slow down movement
  const gravity = 200; // Gravity pulling player down
  const fuelConsumptionRate = 25; // Fuel units per second
  const fuelRegenRate = 15; // Fuel regen per second when not boosting
  
  // Update player state
  function update(deltaTime: number, inputState: InputState, mousePosition: Vector2D) {
    // Update rotation based on mouse position
    rotation = Math.atan2(
      mousePosition.y - position.y,
      mousePosition.x - position.x
    );
    
    // Reset acceleration
    acceleration.x = 0;
    acceleration.y = 0;
    
    // Apply gravity
    acceleration.y += gravity;
    
    // Handle rocket boost
    let boosting = false;
    if (inputState.boost && fuel > 0) {
      boosting = true;
      acceleration.y -= boostSpeed;
      fuel = Math.max(0, fuel - fuelConsumptionRate * deltaTime);
    } else if (fuel < maxFuel) {
      // Regenerate fuel when not boosting
      fuel = Math.min(maxFuel, fuel + fuelRegenRate * deltaTime);
    }
    
    // Handle horizontal movement
    if (inputState.left) {
      acceleration.x -= moveSpeed;
    }
    if (inputState.right) {
      acceleration.x += moveSpeed;
    }
    
    // Handle vertical movement (when not boosting with rockets)
    if (!boosting) {
      if (inputState.up) {
        acceleration.y -= moveSpeed;
      }
      if (inputState.down) {
        acceleration.y += moveSpeed;
      }
    }
    
    // Apply acceleration
    velocity.x += acceleration.x * deltaTime;
    velocity.y += acceleration.y * deltaTime;
    
    // Apply friction
    velocity.x *= Math.pow(friction, deltaTime * 10);
    velocity.y *= Math.pow(friction, deltaTime * 10);
    
    // Update position
    position.x += velocity.x * deltaTime;
    position.y += velocity.y * deltaTime;
    
    // Handle world boundaries
    const canvas = document.querySelector('canvas');
    if (canvas) {
      // Bounce off edges with some dampening
      if (position.x - radius < 0) {
        position.x = radius;
        velocity.x = Math.abs(velocity.x) * 0.5;
      } else if (position.x + radius > canvas.width) {
        position.x = canvas.width - radius;
        velocity.x = -Math.abs(velocity.x) * 0.5;
      }
      
      if (position.y - radius < 0) {
        position.y = radius;
        velocity.y = Math.abs(velocity.y) * 0.5;
      } else if (position.y + radius > canvas.height) {
        position.y = canvas.height - radius;
        velocity.y = -Math.abs(velocity.y) * 0.5;
      }
    }
    
    // Update weapon cooldown
    if (shootCooldown > 0) {
      shootCooldown -= deltaTime;
    }
    
    // Handle reloading
    if (ammo <= 0 && reloadTime <= 0) {
      reloadTime = fullReloadTime;
    }
    
    if (reloadTime > 0) {
      reloadTime -= deltaTime;
      if (reloadTime <= 0) {
        ammo = maxAmmo;
      }
    }
    
    // Update damage boost timer
    if (damageBoostTimer > 0) {
      damageBoostTimer -= deltaTime;
      if (damageBoostTimer <= 0) {
        damageMultiplier = 1;
      }
    }
  }
  
  function getAimDirection() {
    return rotation;
  }
  
  function canShoot() {
    return shootCooldown <= 0 && ammo > 0 && reloadTime <= 0;
  }
  
  function shoot() {
    if (canShoot()) {
      ammo--;
      shootCooldown = shootCooldownTime;
      return true;
    }
    return false;
  }
  
  function takeDamage(amount: number) {
    health = Math.max(0, health - amount);
  }
  
  function heal(amount: number) {
    health = Math.min(maxHealth, health + amount);
  }
  
  function addAmmo(amount: number) {
    ammo = Math.min(maxAmmo, ammo + amount);
  }
  
  function activateDamageBoost(multiplier: number, duration: number) {
    damageMultiplier = multiplier;
    damageBoostTimer = duration;
    damageBoostDuration = duration;
  }
  
  return {
    position,
    velocity,
    radius,
    get rotation() { return rotation; },
    get health() { return health; },
    get maxHealth() { return maxHealth; },
    get ammo() { return ammo; },
    get fuel() { return fuel; },
    get damageMultiplier() { return damageMultiplier; },
    get damageBoostTimer() { return damageBoostTimer; },
    get damageBoostDuration() { return damageBoostDuration; },
    update,
    getAimDirection,
    canShoot,
    shoot,
    takeDamage,
    heal,
    addAmmo,
    activateDamageBoost
  };
}