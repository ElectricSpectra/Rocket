import { Vector2D } from '../utils/vector';
import { GameObject } from './player';

interface NPCStats {
  health: number;
  damage: number;
  speed: number;
  radius: number;
  shootCooldown: number;
}

export function createNPC(
  spawnPosition: Vector2D,
  waveNumber: number = 1,
  customStats?: Partial<NPCStats>
) {
  // Scale difficulty with wave number
  const difficultyMultiplier = 1 + (waveNumber - 1) * 0.1;

  // NPC state
  const position: Vector2D = { ...spawnPosition };
  const velocity: Vector2D = { x: 0, y: 0 };
  let rotation = 0;
  const baseHealth = customStats?.health || 50;
  let health = Math.floor(baseHealth * difficultyMultiplier);
  const maxHealth = health;
  let shootCooldown = 0;
  const shootCooldownTime = customStats?.shootCooldown || 1.5;
  
  // NPC constants
  const radius = customStats?.radius || 15;
  const moveSpeed = customStats?.speed || 120;
  const baseDamage = customStats?.damage || 10;
  const damage = Math.floor(baseDamage * difficultyMultiplier);
  const aggroDistance = 400;
  const shootDistance = 250;
  const aimAccuracy = Math.min(0.85 + (waveNumber - 1) * 0.02, 0.95);
  
  function update(deltaTime: number, playerPosition: Vector2D) {
    const dx = playerPosition.x - position.x;
    const dy = playerPosition.y - position.y;
    const distToPlayer = Math.sqrt(dx * dx + dy * dy);
    
    const targetRotation = Math.atan2(dy, dx);
    const rotationDiff = targetRotation - rotation;
    
    let normalizedDiff = rotationDiff;
    if (rotationDiff > Math.PI) normalizedDiff -= Math.PI * 2;
    if (rotationDiff < -Math.PI) normalizedDiff += Math.PI * 2;
    
    rotation += normalizedDiff * deltaTime * 5;
    
    if (rotation > Math.PI * 2) rotation -= Math.PI * 2;
    if (rotation < 0) rotation += Math.PI * 2;
    
    velocity.x = 0;
    velocity.y = 0;
    
    if (distToPlayer < aggroDistance) {
      const moveDir = {
        x: dx / distToPlayer,
        y: dy / distToPlayer
      };
      
      const speedMultiplier = distToPlayer < shootDistance * 1.2 ? 0.6 : 1.0;
      
      if (distToPlayer < 100) {
        velocity.x = -moveDir.x * moveSpeed * deltaTime;
        velocity.y = -moveDir.y * moveSpeed * deltaTime;
      } else {
        velocity.x = moveDir.x * moveSpeed * speedMultiplier * deltaTime;
        velocity.y = moveDir.y * moveSpeed * speedMultiplier * deltaTime;
      }
    }
    
    position.x += velocity.x;
    position.y += velocity.y;
    
    const canvas = document.querySelector('canvas');
    if (canvas) {
      if (position.x - radius < 0) {
        position.x = radius;
      } else if (position.x + radius > canvas.width) {
        position.x = canvas.width - radius;
      }
      
      if (position.y - radius < 0) {
        position.y = radius;
      } else if (position.y + radius > canvas.height) {
        position.y = canvas.height - radius;
      }
    }
    
    if (shootCooldown > 0) {
      shootCooldown -= deltaTime;
    }
  }
  
  function getAimDirection(playerPosition?: Vector2D) {
    if (playerPosition) {
      const dx = playerPosition.x - position.x;
      const dy = playerPosition.y - position.y;
      const baseAngle = Math.atan2(dy, dx);
      
      const inaccuracy = (1 - aimAccuracy) * (Math.random() * 0.4 - 0.2);
      return baseAngle + inaccuracy;
    }
    return rotation;
  }
  
  function canShoot() {
    return shootCooldown <= 0;
  }
  
  function shoot() {
    if (canShoot()) {
      shootCooldown = shootCooldownTime;
      return true;
    }
    return false;
  }
  
  function takeDamage(amount: number) {
    health = Math.max(0, health - amount);
  }

  function heal(amount: number) {
    health = Math.min(maxHealth, health + amount);
  }
  
  return {
    position,
    velocity,
    radius,
    get rotation() { return rotation; },
    get health() { return health; },
    get maxHealth() { return maxHealth; },
    get damage() { return damage; },
    isBoss: false,
    update,
    getAimDirection,
    canShoot,
    shoot,
    takeDamage,
    heal
  };
}