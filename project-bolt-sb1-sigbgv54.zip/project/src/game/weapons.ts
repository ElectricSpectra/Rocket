import { Vector2D } from '../utils/vector';

export interface Projectile {
  position: Vector2D;
  velocity: Vector2D;
  radius: number;
  damage: number;
  owner: 'player' | 'npc';
  speed: number;
  update: (deltaTime: number) => void;
}

export function createProjectile(
  position: Vector2D, 
  direction: number, 
  owner: 'player' | 'npc',
  damageMultiplier: number = 1
): Projectile {
  const speed = 500; // Speed in pixels per second
  const baseDamage = owner === 'player' ? 25 : 10;
  const damage = owner === 'player' ? baseDamage * damageMultiplier : baseDamage;
  const radius = 4;
  
  // Calculate velocity based on direction and speed
  const velocity = {
    x: Math.cos(direction) * speed,
    y: Math.sin(direction) * speed
  };
  
  function update(deltaTime: number) {
    position.x += velocity.x * deltaTime;
    position.y += velocity.y * deltaTime;
  }
  
  return {
    position,
    velocity,
    radius,
    damage,
    owner,
    speed,
    update
  };
}