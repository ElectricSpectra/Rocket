import { Vector2D } from '../utils/vector';
import { createNPC } from './npc';

type BossType = 'TANK' | 'BERSERKER' | 'SNIPER';

interface BossStats {
  health: number;
  damage: number;
  speed: number;
  shootCooldown: number;
  size: number;
}

export function createBoss(position: Vector2D, waveNumber: number) {
  // Determine boss type based on wave number
  const bossTypes: BossType[] = ['TANK', 'BERSERKER', 'SNIPER'];
  const bossType = bossTypes[(waveNumber / 3 - 1) % bossTypes.length];

  // Base stats that scale with wave number
  const baseStats: Record<BossType, BossStats> = {
    TANK: {
      health: 200,
      damage: 15,
      speed: 80,
      shootCooldown: 2,
      size: 25
    },
    BERSERKER: {
      health: 150,
      damage: 20,
      speed: 150,
      shootCooldown: 0.8,
      size: 20
    },
    SNIPER: {
      health: 100,
      damage: 30,
      speed: 100,
      shootCooldown: 3,
      size: 18
    }
  };

  // Scale stats based on wave number
  const scalingFactor = 1 + (waveNumber - 3) * 0.2;
  const stats = baseStats[bossType];
  const scaledStats = {
    ...stats,
    health: Math.floor(stats.health * scalingFactor),
    damage: Math.floor(stats.damage * scalingFactor)
  };

  // Create base NPC with modified stats
  const boss = createNPC(position, waveNumber, {
    health: scaledStats.health,
    damage: scaledStats.damage,
    speed: scaledStats.speed,
    radius: scaledStats.size,
    shootCooldown: scaledStats.shootCooldown
  });

  // Add boss-specific behaviors
  let specialAttackCooldown = 0;
  const specialAttackDelay = 5; // 5 seconds between special attacks

  function update(deltaTime: number, playerPosition: Vector2D) {
    // Update base NPC behavior
    boss.update(deltaTime, playerPosition);

    // Update special attack cooldown
    if (specialAttackCooldown > 0) {
      specialAttackCooldown -= deltaTime;
    }

    // Trigger special attacks based on boss type and health percentage
    if (specialAttackCooldown <= 0) {
      const healthPercent = boss.health / scaledStats.health;

      switch (bossType) {
        case 'TANK':
          if (healthPercent < 0.5) {
            // Tank becomes more defensive at low health
            boss.heal(20);
          }
          break;
        case 'BERSERKER':
          if (healthPercent < 0.3) {
            // Berserker becomes more aggressive at low health
            scaledStats.damage *= 1.5;
            scaledStats.speed *= 1.3;
          }
          break;
        case 'SNIPER':
          if (healthPercent < 0.7) {
            // Sniper becomes more precise and deadly
            scaledStats.damage *= 1.2;
            scaledStats.shootCooldown *= 0.8;
          }
          break;
      }

      specialAttackCooldown = specialAttackDelay;
    }
  }

  return {
    ...boss,
    type: bossType,
    update,
    isBoss: true
  };
}