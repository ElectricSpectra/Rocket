import { Vector2D } from '../utils/vector';

export type PowerUpType = 'health' | 'ammo' | 'damage';

export interface PowerUp {
  position: Vector2D;
  type: PowerUpType;
  radius: number;
  value: number;
  duration?: number;
  collected: boolean;
  update: (deltaTime: number) => void;
}

export function createPowerUp(
  position: Vector2D,
  type: PowerUpType
): PowerUp {
  const radius = 10;
  let collected = false;
  let floatOffset = 0;
  const floatSpeed = 2;
  const floatAmount = 5;
  
  // Power-up values
  const values = {
    health: 50,
    ammo: 30,
    damage: 2 // Damage multiplier
  };
  
  // Duration for temporary effects (in seconds)
  const durations = {
    damage: 10
  };
  
  function update(deltaTime: number) {
    // Create a floating animation
    floatOffset = Math.sin(Date.now() / 1000 * floatSpeed) * floatAmount;
    position.y += floatOffset * deltaTime;
  }
  
  return {
    position,
    type,
    radius,
    value: values[type],
    duration: durations[type],
    collected,
    update
  };
}