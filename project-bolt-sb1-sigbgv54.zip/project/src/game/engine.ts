import { useCallback, useEffect, useRef, useState } from 'react';
import { createPlayer } from './player';
import { createNPC } from './npc';
import { checkCollision } from '../utils/collision';
import { handleInput, InputState } from '../utils/input';
import { Projectile, createProjectile } from './weapons';
import { Vector2D } from '../utils/vector';
import { PowerUp, createPowerUp } from './powerups';
import { createWaveManager } from './waves';

interface GameEngineProps {
  canvasRef: React.RefObject<HTMLCanvasElement>;
  onScoreChange: (score: number) => void;
  onHealthChange: (health: number) => void;
  onAmmoChange: (ammo: number) => void;
  onFuelChange: (fuel: number) => void;
  onWaveChange: (wave: number) => void;
  onGameOver: () => void;
}

interface GameState {
  score: number;
  running: boolean;
  lastTimestamp: number;
  player: ReturnType<typeof createPlayer> | null;
  npcs: ReturnType<typeof createNPC>[];
  projectiles: Projectile[];
  powerUps: PowerUp[];
  inputState: InputState;
  spawnTimer: number;
  powerUpTimer: number;
  gameArea: { width: number; height: number };
  mousePosition: Vector2D;
  waveManager: ReturnType<typeof createWaveManager> | null;
}

export const useGameEngine = ({
  canvasRef,
  onScoreChange,
  onHealthChange,
  onAmmoChange,
  onFuelChange,
  onWaveChange,
  onGameOver
}: GameEngineProps) => {
  const [initialized, setInitialized] = useState(false);
  const gameState = useRef<GameState>({
    score: 0,
    running: false,
    lastTimestamp: 0,
    player: null,
    npcs: [],
    projectiles: [],
    powerUps: [],
    inputState: {
      left: false,
      right: false,
      up: false,
      down: false,
      shoot: false,
      boost: false,
    },
    spawnTimer: 0,
    powerUpTimer: 0,
    gameArea: { width: 0, height: 0 },
    mousePosition: { x: 0, y: 0 },
    waveManager: null
  });
  const animationFrameId = useRef<number>(0);

  // Initialize the game engine
  useEffect(() => {
    if (!canvasRef.current || initialized) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
      
      gameState.current.gameArea = {
        width: canvas.width,
        height: canvas.height
      };
    };

    // Set up event handlers
    const setupEventHandlers = () => {
      window.addEventListener('keydown', (e) => {
        handleInput(e, true, gameState.current.inputState);
      });
      
      window.addEventListener('keyup', (e) => {
        handleInput(e, false, gameState.current.inputState);
      });
      
      canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        gameState.current.mousePosition = {
          x: e.clientX - rect.left,
          y: e.clientY - rect.top
        };
      });
      
      canvas.addEventListener('mousedown', () => {
        gameState.current.inputState.shoot = true;
      });
      
      canvas.addEventListener('mouseup', () => {
        gameState.current.inputState.shoot = false;
      });
      
      canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length > 0) {
          const rect = canvas.getBoundingClientRect();
          gameState.current.mousePosition = {
            x: e.touches[0].clientX - rect.left,
            y: e.touches[0].clientY - rect.top
          };
          e.preventDefault();
        }
      });
      
      canvas.addEventListener('touchstart', () => {
        gameState.current.inputState.shoot = true;
      });
      
      canvas.addEventListener('touchend', () => {
        gameState.current.inputState.shoot = false;
      });
    };

    resizeCanvas();
    setupEventHandlers();
    window.addEventListener('resize', resizeCanvas);
    
    setInitialized(true);
    
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('keydown', (e) => handleInput(e, true, gameState.current.inputState));
      window.removeEventListener('keyup', (e) => handleInput(e, false, gameState.current.inputState));
    };
  }, [canvasRef, initialized]);

  const gameLoop = useCallback((timestamp: number) => {
    if (!gameState.current.running) return;
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const deltaTime = (timestamp - gameState.current.lastTimestamp) / 1000;
    gameState.current.lastTimestamp = timestamp;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    updateGameState(deltaTime);
    renderGame(ctx);
    
    animationFrameId.current = requestAnimationFrame(gameLoop);
  }, [canvasRef]);

  const updateGameState = useCallback((deltaTime: number) => {
    const state = gameState.current;
    
    if (!state.player || !state.waveManager) return;
    
    state.player.update(deltaTime, state.inputState, state.mousePosition);
    
    onHealthChange(state.player.health);
    onAmmoChange(state.player.ammo);
    onFuelChange(state.player.fuel);
    
    if (state.inputState.shoot && state.player.canShoot()) {
      const projectile = createProjectile(
        { ...state.player.position },
        state.player.getAimDirection(),
        'player',
        state.player.damageMultiplier
      );
      state.projectiles.push(projectile);
      state.player.shoot();
    }
    
    // Update wave system
    const newEnemy = state.waveManager.update(
      deltaTime,
      state.gameArea,
      state.player.position,
      state.score
    );

    if (newEnemy) {
      state.npcs.push(newEnemy);
    }

    // Check if we should advance to next wave
    if (state.waveManager.checkScoreForNextWave(state.score)) {
      state.waveManager.startNextWave();
      onWaveChange(state.waveManager.currentWave.number);
    }
    
    state.npcs.forEach(npc => {
      npc.update(deltaTime, state.player.position);
      
      if (npc.canShoot() && state.player) {
        const projectile = createProjectile(
          { ...npc.position },
          npc.getAimDirection(state.player.position),
          'npc'
        );
        state.projectiles.push(projectile);
        npc.shoot();
      }
    });
    
    state.projectiles.forEach((projectile, index) => {
      projectile.update(deltaTime);
      
      if (
        projectile.position.x < 0 ||
        projectile.position.x > state.gameArea.width ||
        projectile.position.y < 0 ||
        projectile.position.y > state.gameArea.height
      ) {
        state.projectiles.splice(index, 1);
        return;
      }
      
      if (
        projectile.owner !== 'player' &&
        state.player &&
        checkCollision(projectile, state.player)
      ) {
        state.player.takeDamage(projectile.damage);
        state.projectiles.splice(index, 1);
        return;
      }
      
      state.npcs.forEach((npc, npcIndex) => {
        if (
          projectile.owner !== 'npc' &&
          checkCollision(projectile, npc)
        ) {
          npc.takeDamage(projectile.damage);
          state.projectiles.splice(index, 1);
          
          if (npc.health <= 0) {
            state.waveManager?.onEnemyDefeated(npc.isBoss);
            state.npcs.splice(npcIndex, 1);
            state.score += npc.isBoss ? 50 : 10;
            onScoreChange(state.score);
            
            if (Math.random() < 0.3) {
              const powerUpTypes: ('health' | 'ammo' | 'damage')[] = ['health', 'ammo', 'damage'];
              const randomType = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
              const powerUp = createPowerUp({ ...npc.position }, randomType);
              state.powerUps.push(powerUp);
            }
          }
          return;
        }
      });
    });
    
    state.powerUps.forEach((powerUp, index) => {
      powerUp.update(deltaTime);
      
      if (!powerUp.collected && state.player && checkCollision(powerUp, state.player)) {
        powerUp.collected = true;
        
        switch (powerUp.type) {
          case 'health':
            state.player.heal(powerUp.value);
            break;
          case 'ammo':
            state.player.addAmmo(powerUp.value);
            break;
          case 'damage':
            state.player.activateDamageBoost(powerUp.value, powerUp.duration || 0);
            break;
        }
        
        state.powerUps.splice(index, 1);
      }
    });
    
    if (state.player && state.player.health <= 0) {
      onGameOver();
    }
  }, [onHealthChange, onAmmoChange, onFuelChange, onScoreChange, onGameOver, onWaveChange]);

  const renderGame = useCallback((ctx: CanvasRenderingContext2D) => {
    const state = gameState.current;
    
    ctx.fillStyle = '#1a202c';
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    
    ctx.strokeStyle = '#2d3748';
    ctx.lineWidth = 1;
    const gridSize = 50;
    
    for (let x = 0; x < ctx.canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, ctx.canvas.height);
      ctx.stroke();
    }
    
    for (let y = 0; y < ctx.canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(ctx.canvas.width, y);
      ctx.stroke();
    }
    
    state.powerUps.forEach(powerUp => {
      ctx.fillStyle = powerUp.type === 'health' ? '#48bb78' : 
                     powerUp.type === 'ammo' ? '#4299e1' : 
                     '#ed8936';
      
      ctx.beginPath();
      ctx.arc(powerUp.position.x, powerUp.position.y, powerUp.radius, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(
        powerUp.type === 'health' ? '+' :
        powerUp.type === 'ammo' ? 'A' : 'D',
        powerUp.position.x,
        powerUp.position.y
      );
    });
    
    state.projectiles.forEach(projectile => {
      ctx.fillStyle = projectile.owner === 'player' ? '#3b82f6' : '#ef4444';
      ctx.beginPath();
      ctx.arc(projectile.position.x, projectile.position.y, projectile.radius, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.strokeStyle = projectile.owner === 'player' ? 'rgba(59, 130, 246, 0.5)' : 'rgba(239, 68, 68, 0.5)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(projectile.position.x, projectile.position.y);
      ctx.lineTo(
        projectile.position.x - projectile.velocity.x * 0.3,
        projectile.position.y - projectile.velocity.y * 0.3
      );
      ctx.stroke();
    });
    
    state.npcs.forEach(npc => {
      // Draw boss differently
      if (npc.isBoss) {
        ctx.fillStyle = '#9333ea'; // Purple for bosses
        ctx.beginPath();
        ctx.arc(npc.position.x, npc.position.y, npc.radius, 0, Math.PI * 2);
        ctx.fill();

        // Draw boss crown
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(npc.position.x - npc.radius * 0.5, npc.position.y - npc.radius - 5);
        ctx.lineTo(npc.position.x + npc.radius * 0.5, npc.position.y - npc.radius - 5);
        ctx.lineTo(npc.position.x + npc.radius * 0.3, npc.position.y - npc.radius - 15);
        ctx.lineTo(npc.position.x, npc.position.y - npc.radius - 5);
        ctx.lineTo(npc.position.x - npc.radius * 0.3, npc.position.y - npc.radius - 15);
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(npc.position.x, npc.position.y, npc.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      
      const dirX = Math.cos(npc.rotation) * npc.radius;
      const dirY = Math.sin(npc.rotation) * npc.radius;
      
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(npc.position.x, npc.position.y);
      ctx.lineTo(npc.position.x + dirX, npc.position.y + dirY);
      ctx.stroke();
      
      const healthBarWidth = npc.radius * 2;
      const healthBarHeight = 4;
      const healthPercent = npc.health / npc.maxHealth;
      
      ctx.fillStyle = '#4b5563';
      ctx.fillRect(
        npc.position.x - healthBarWidth / 2,
        npc.position.y - npc.radius - 10,
        healthBarWidth,
        healthBarHeight
      );
      
      ctx.fillStyle = npc.isBoss ? '#9333ea' : '#ef4444';
      ctx.fillRect(
        npc.position.x - healthBarWidth / 2,
        npc.position.y - npc.radius - 10,
        healthBarWidth * healthPercent,
        healthBarHeight
      );
    });
    
    if (state.player) {
      if (state.inputState.boost && state.player.fuel > 0) {
        ctx.fillStyle = 'rgba(251, 191, 36, 0.7)';
        ctx.beginPath();
        
        const boostAngle = Math.atan2(
          state.player.velocity.y,
          state.player.velocity.x
        ) + Math.PI;
        
        const x1 = state.player.position.x + Math.cos(boostAngle - 0.3) * state.player.radius * 1.2;
        const y1 = state.player.position.y + Math.sin(boostAngle - 0.3) * state.player.radius * 1.2;
        const x2 = state.player.position.x + Math.cos(boostAngle) * state.player.radius * 2;
        const y2 = state.player.position.y + Math.sin(boostAngle) * state.player.radius * 2;
        const x3 = state.player.position.x + Math.cos(boostAngle + 0.3) * state.player.radius * 1.2;
        const y3 = state.player.position.y + Math.sin(boostAngle + 0.3) * state.player.radius * 1.2;
        
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.lineTo(x3, y3);
        ctx.closePath();
        ctx.fill();
      }
      
      ctx.fillStyle = state.player.damageMultiplier > 1 ? '#9f7aea' : '#3b82f6';
      ctx.beginPath();
      ctx.arc(state.player.position.x, state.player.position.y, state.player.radius, 0, Math.PI * 2);
      ctx.fill();
      
      const aimDirection = state.player.getAimDirection();
      const dirX = Math.cos(aimDirection) * state.player.radius;
      const dirY = Math.sin(aimDirection) * state.player.radius;
      
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(state.player.position.x, state.player.position.y);
      ctx.lineTo(state.player.position.x + dirX, state.player.position.y + dirY);
      ctx.stroke();
      
      if (state.player.damageBoostTimer > 0) {
        const timerWidth = state.player.radius * 2;
        const timerHeight = 3;
        const timerPercent = state.player.damageBoostTimer / state.player.damageBoostDuration;
        
        ctx.fillStyle = '#4a5568';
        ctx.fillRect(
          state.player.position.x - timerWidth / 2,
          state.player.position.y + state.player.radius + 5,
          timerWidth,
          timerHeight
        );
        
        ctx.fillStyle = '#9f7aea';
        ctx.fillRect(
          state.player.position.x - timerWidth / 2,
          state.player.position.y + state.player.radius + 5,
          timerWidth * timerPercent,
          timerHeight
        );
      }
    }
  }, []);

  const startGame = useCallback(() => {
    if (gameState.current.running) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    gameState.current = {
      ...gameState.current,
      score: 0,
      running: true,
      lastTimestamp: performance.now(),
      player: createPlayer({
        x: canvas.width / 2,
        y: canvas.height / 2
      }),
      npcs: [],
      projectiles: [],
      powerUps: [],
      spawnTimer: 1,
      powerUpTimer: 0,
      waveManager: createWaveManager()
    };
    
    onScoreChange(0);
    onWaveChange(1);
    
    animationFrameId.current = requestAnimationFrame(gameLoop);
  }, [canvasRef, gameLoop, onScoreChange, onWaveChange]);

  const stopGame = useCallback(() => {
    gameState.current.running = false;
    cancelAnimationFrame(animationFrameId.current);
  }, []);

  const restartGame = useCallback(() => {
    startGame();
  }, [startGame]);

  return {
    startGame,
    stopGame,
    restartGame
  };
};